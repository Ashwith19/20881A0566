import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Switch } from 'react-router-dom';
import { getTrainById } from '../services/api';
import TrainCard from '../components/TrainCard';

const SingleTrainPage = () => {
  const { id } = useParams();
  const [train, setTrain] = useState(null);

  useEffect(() => {
    fetchTrain();
  }, []);

  const fetchTrain = async () => {
    try {
      const response = await getTrainById(id);
      setTrain(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h1>Single Train</h1>
      {train ? <TrainCard train={train} /> : <p>Loading train...</p>}
    </div>
  );
};

export default SingleTrainPage;
