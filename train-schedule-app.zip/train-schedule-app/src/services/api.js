import axios from 'axios';
import { Switch } from 'react-router-dom';


const API_BASE_URL = 'http://your-backend-api-url.com'; // Replace with your actual backend API URL

export const getAllTrains = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/trains`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getTrainById = async (id) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/trains/${id}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};
