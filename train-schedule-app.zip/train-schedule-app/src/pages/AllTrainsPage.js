import React, { useEffect, useState } from 'react';
import TrainCard from '../components/TrainCard';
import { getAllTrains } from '../services/api';

const AllTrainsPage = () => {
  const [trains, setTrains] = useState([]);

  useEffect(() => {
    fetchTrains();
  }, []);

  const fetchTrains = async () => {
    try {
      const response = await getAllTrains();
      setTrains(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h1>All Trains</h1>
      {trains.map((train) => (
        <TrainCard key={train.id} train={train} />
      ))}
    </div>
  );
};

export default AllTrainsPage;
