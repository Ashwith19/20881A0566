import React from 'react';
import { Switch } from 'react-router-dom';


const TrainCard = ({ train }) => {
  return (
    <div className="train-card">
      <h3>{train.name}</h3>
      <p>Departure: {train.departure}</p>
      <p>Destination: {train.destination}</p>
      <p>Delay: {train.delay}</p>
      <p>Price: {train.price}</p>
      <p>Availability: {train.availability}</p>
      <p>Class: {train.class}</p>
    </div>
  );
};

export default TrainCard;
